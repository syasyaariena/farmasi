<html>
<head>
<title>
Farmasi Login
</title>
  <link rel='stylesheet' href="stylesheet.css">
</head>
<body >


<div id="box">
<center>
<span class="normal">Register</span>
</center>
<form action="prosuser.php" method= "post">

<label class="label-3">name: </label>
<input type="text" name="name" class='textbox-3'><br>
<label class="label-3">username: </label>
<input type="text" name="username" class='textbox-3'><br>
<label class="label-3">email: </label>
<input type="text" name="email" class='textbox-3'><br>
<label class="label-3">password: </label>
<input type="password" name="password" class='textbox-3'><br>
<div class= "btn-register">
<input type="submit" value="REGISTER" class="btn-3">
</form>
<a href="index.php" class="btn-link">LOG IN</a>
</div>
</div>
</body>
</html>