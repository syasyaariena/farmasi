<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "farmasi"; // tidak memasukkan nama db

// Create connection
$conn = mysqli_connect("localhost","root","","farmasi"); // tidak meletak nama db
$db = mysqli_select_db($conn,"farmasi"); //tidak memanggil pemboleh ubah 
echo "databases not connected";
?>
