<?php
$servername = "localhost";
$username = "root";
$password = ""
$database = "";

// Create connection
$conn = mysql_connect("localhost","root","");
$db = mysql_select_db("farmasi");
echo "databases not connected";
?>